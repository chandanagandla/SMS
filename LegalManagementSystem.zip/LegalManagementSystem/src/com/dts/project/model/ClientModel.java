package com.dts.project.model;

public class ClientModel {
	
	private int clientid;
	private String clientfstname;
	private String clientlstname;
	private String clientmidname;
	private String clientftherfstname;
	private String clientftherlstname;
	private String clientfthermidname;
	private String dobofclient;
	private String dobofclientfather;
	private String doregistration;
	private int userid;
	private String emailid;
	public int getClientid() {
		return clientid;
	}
	public void setClientid(int clientid) {
		this.clientid = clientid;
	}
	public String getClientfstname() {
		return clientfstname;
	}
	public void setClientfstname(String clientfstname) {
		this.clientfstname = clientfstname;
	}
	public String getClientlstname() {
		return clientlstname;
	}
	public void setClientlstname(String clientlstname) {
		this.clientlstname = clientlstname;
	}
	public String getClientmidname() {
		return clientmidname;
	}
	public void setClientmidname(String clientmidname) {
		this.clientmidname = clientmidname;
	}
	public String getClientftherfstname() {
		return clientftherfstname;
	}
	public void setClientftherfstname(String clientftherfstname) {
		this.clientftherfstname = clientftherfstname;
	}
	public String getClientftherlstname() {
		return clientftherlstname;
	}
	public void setClientftherlstname(String clientftherlstname) {
		this.clientftherlstname = clientftherlstname;
	}
	public String getClientfthermidname() {
		return clientfthermidname;
	}
	public void setClientfthermidname(String clientfthermidname) {
		this.clientfthermidname = clientfthermidname;
	}
	public String getDobofclient() {
		return dobofclient;
	}
	public void setDobofclient(String dobofclient) {
		this.dobofclient = dobofclient;
	}
	public String getDobofclientfather() {
		return dobofclientfather;
	}
	public void setDobofclientfather(String dobofclientfather) {
		this.dobofclientfather = dobofclientfather;
	}
	public String getDoregistration() {
		return doregistration;
	}
	public void setDoregistration(String doregistration) {
		this.doregistration = doregistration;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

}
