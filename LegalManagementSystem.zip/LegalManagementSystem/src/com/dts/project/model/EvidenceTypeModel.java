package com.dts.project.model;

public class EvidenceTypeModel {
	private int evidencetypeid;
	private String evidencetypename;
	private String evidencetypeabbr;
	private String evidencetypedesc;
	public int getEvidencetypeid() {
		return evidencetypeid;
	}
	public void setEvidencetypeid(int evidencetypeid) {
		this.evidencetypeid = evidencetypeid;
	}
	public String getEvidencetypename() {
		return evidencetypename;
	}
	public void setEvidencetypename(String evidencetypename) {
		this.evidencetypename = evidencetypename;
	}
	public String getEvidencetypeabbr() {
		return evidencetypeabbr;
	}
	public void setEvidencetypeabbr(String evidencetypeabbr) {
		this.evidencetypeabbr = evidencetypeabbr;
	}
	public String getEvidencetypedesc() {
		return evidencetypedesc;
	}
	public void setEvidencetypedesc(String evidencetypedesc) {
		this.evidencetypedesc = evidencetypedesc;
	}

}
