package com.dts.project.model;

public class LawyerTypeModel {
	private int lawyertypeid;
	private String lawyertypename;
	private String lawyertypeabbr;
	private String lawyertypedesc;
	public int getLawyertypeid() {
		return lawyertypeid;
	}
	public void setLawyertypeid(int lawyertypeid) {
		this.lawyertypeid = lawyertypeid;
	}
	public String getLawyertypename() {
		return lawyertypename;
	}
	public void setLawyertypename(String lawyertypename) {
		this.lawyertypename = lawyertypename;
	}
	public String getLawyertypeabbr() {
		return lawyertypeabbr;
	}
	public void setLawyertypeabbr(String lawyertypeabbr) {
		this.lawyertypeabbr = lawyertypeabbr;
	}
	public String getLawyertypedesc() {
		return lawyertypedesc;
	}
	public void setLawyertypedesc(String lawyertypedesc) {
		this.lawyertypedesc = lawyertypedesc;
	}

}
