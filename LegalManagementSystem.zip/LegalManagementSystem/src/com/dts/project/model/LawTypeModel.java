package com.dts.project.model;

public class LawTypeModel {
	private int lawtypeid;
	private String lawtypename;
	private String lawtypeabbr;
	private String desc;
	public int getLawtypeid() {
		return lawtypeid;
	}
	public void setLawtypeid(int lawtypeid) {
		this.lawtypeid = lawtypeid;
	}
	public String getLawtypename() {
		return lawtypename;
	}
	public void setLawtypename(String lawtypename) {
		this.lawtypename = lawtypename;
	}
	public String getLawtypeabbr() {
		return lawtypeabbr;
	}
	public void setLawtypeabbr(String lawtypeabbr) {
		this.lawtypeabbr = lawtypeabbr;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}

}
