package com.dts.project.model;

public class CaseTypeModel {
	private int casetypeid;
	private String casetypename;
	private String casetypeabbr;
	private String casetypedesc;
	public int getCasetypeid() {
		return casetypeid;
	}
	public void setCasetypeid(int casetypeid) {
		this.casetypeid = casetypeid;
	}
	public String getCasetypename() {
		return casetypename;
	}
	public void setCasetypename(String casetypename) {
		this.casetypename = casetypename;
	}
	public String getCasetypeabbr() {
		return casetypeabbr;
	}
	public void setCasetypeabbr(String casetypeabbr) {
		this.casetypeabbr = casetypeabbr;
	}
	public String getCasetypedesc() {
		return casetypedesc;
	}
	public void setCasetypedesc(String casetypedesc) {
		this.casetypedesc = casetypedesc;
	}
}
