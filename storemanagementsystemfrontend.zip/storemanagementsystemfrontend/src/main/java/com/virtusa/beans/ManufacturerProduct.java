package com.virtusa.beans;
import java.sql.*;


//import javax.persistence.Entity;
//import javax.persistence.Id;

//@Entity
public class ManufacturerProduct {
	//@Id
	private int Product_id;
	private String product_type;
	private String Product_name;
	private String Manu_Date;
	private float Manu_Cp;
	private int Quantity;
	public int getProduct_id() {
		return Product_id;
	}
	public void setProduct_id(int product_id) {
		this.Product_id = product_id;
	}
	public String getProduct_type() {
		return product_type;
	}
	public void setProduct_type(String product_type) {
		this.product_type = product_type;
	}
	public String getProduct_name() {
		return Product_name;
	}
	public void setProduct_name(String product_name) {
		this.Product_name = product_name;
	}
	public String getManu_Date() {
		return Manu_Date;
	}
	public void setManu_Date(String manu_Date) {
		this.Manu_Date = manu_Date;
	}
	public float getManu_Cp() {
		return Manu_Cp;
	}
	public void setManu_Cp(float manu_Cp) {
		this.Manu_Cp = manu_Cp;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		this.Quantity = quantity;
	}
	
	
}
/*rivate int Product_id;
private String Product_type;
private String Product_name;
private String Manu_Date;
private float Manu_Cp;
private int Quantity;
public int getProduct_id() {
	return Product_id;
}
public void setProduct_id(int product_id) {
	Product_id = product_id;
}
public String getProduct_type() {
	return Product_type;
}
public void setProduct_type(String product_type) {
	Product_type = product_type;
}
public String getProduct_name() {
	return Product_name;
}
public void setProduct_name(String product_name) {
	Product_name = product_name;
}
public String getManu_Date() {
	return Manu_Date;
}
public void setManu_Date(String manu_Date) {
	Manu_Date = manu_Date;
}
public float getManu_Cp() {
	return Manu_Cp;
}
public void setManu_Cp(float manu_Cp) {
	Manu_Cp = manu_Cp;
}
public int getQuantity() {
	return Quantity;
}
public void setQuantity(int quantity) {
	Quantity = quantity;
}*/

