package com.virtusa.controller;


	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Controller;
	import org.springframework.ui.Model;
	import org.springframework.web.bind.annotation.ModelAttribute;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RequestMethod;

	import com.virtusa.beans.*;
	import com.virtusa.controller.*;
	import com.virtusa.dao.DealerDao;

	@Controller
	public class DealerController {
		@Autowired
		DealerDao dao;
		@RequestMapping("/deaform")
		public String showForm(Model m){
			m.addAttribute("command", new Dealer());
			System.out.println("show Form");
			return "deaform";
			
		}
		
		@RequestMapping(value="/savee", method=RequestMethod.POST)
		public String save(@ModelAttribute("dea")Dealer dea){
			dao.insert(dea);
			return "redirect:/viewdealers";
		}
		@RequestMapping("/viewdealers")
		public String viewdea(Model m){
			List<Dealer> deaList= dao.getDealerDetails();
			
			m.addAttribute("deaList",deaList);
			return "viewdealers";
		}
		
		@RequestMapping(value="/editdea/{id}")
		public String edit(@PathVariable int id, Model m){
			Dealer dea=dao.getDeaId(id);
			m.addAttribute("command",dea);
			return "deaeditformjsp";
		}
		@RequestMapping(value="/editsavee",method=RequestMethod.POST)
		public String editSave(@ModelAttribute("dea") Dealer dea){
			dao.update(dea);
			return "redirect:/viewdealers";
		}
		
		@RequestMapping(value="/deletedea/{id}")
		public String delete(@PathVariable int id){
			dao.delete(id);
			return "redirect:/viewdealers";
		}
		
		
	}


