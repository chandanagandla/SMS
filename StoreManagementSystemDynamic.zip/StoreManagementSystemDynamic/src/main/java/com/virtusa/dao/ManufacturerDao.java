package com.virtusa.dao;
	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.hibernate.Transaction;
	import com.virtusa.beans.*;
	import com.virtusa.dao.ManufacturerMapper;
	import org.hibernate.cfg.Configuration;		
		import java.util.List;
		import org.springframework.jdbc.core.JdbcTemplate;
		public class ManufacturerDao {
			  
			JdbcTemplate template;
			public void setTemplate(JdbcTemplate template){
				this.template=template;
			}
			/*&public int insert(Manufacturer emp){
				String sql="insert into Employee(id,name,designation,salary)values(?,?,?,?)";
				int ans=template.update(sql,emp.getEid(),emp.getName(),emp.getDesignation(),emp.getSalary());
				return ans;
			}

			public int update(Employee emp){
				String sql="update Employee set name=?, designation=?, salary=? where id=?";
				int ans=template.update(sql,emp.getName(),emp.getDesignation(),emp.getSalary(),emp.getEid());
				return ans;
			}
			public int delete(int id){
				String sql="delete from employee where id=?";
				return template.update(sql,id);
			}
			public Employee getEmpId(int id){
				String sql="select * from Employee where id=?";
				Employee emp=template.queryForObject(sql,new Object[]{id},new EmployeeMapper());
				
				return emp;
			}*/
			
			public List<Manufacturer> getManufacturerDetails(){
				String sql="select * from Manufacturer";
				List<Manufacturer>manList=template.query(sql,new ManufacturerMapper());
				return manList;
			}
			
			
			
		}



