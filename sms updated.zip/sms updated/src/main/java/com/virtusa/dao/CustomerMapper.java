package com.virtusa.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.virtusa.beans.*;

public class CustomerMapper implements RowMapper<Customer>{

	@Override
	public Customer mapRow(ResultSet rs, int rowNum)throws SQLException{
		Customer cus =new Customer();
    cus.setId(rs.getInt(1));
    cus.setName(rs.getString(2));
    cus.setEmail(rs.getString(3));
    cus.setPhonenumber(rs.getString(4));
    cus.setProduct_id(rs.getInt(5));
    cus.setQuantity(rs.getInt(6));
    cus.setPrice(rs.getFloat(7));
    
		
		return cus;
	}
	

}
