package com.virtusa.dao;


	import java.sql.ResultSet;
	import java.sql.SQLException;

	import org.springframework.jdbc.core.RowMapper;

	import com.virtusa.beans.*;

	public class ManuBillMapper implements RowMapper<ManufacturerBills>{

		@Override
		public ManufacturerBills  mapRow(ResultSet rs, int rowNum)throws SQLException{
			ManufacturerBills mb =new ManufacturerBills();
	    mb.setBill_id(rs.getInt(1));
	    mb.setBill_date(rs.getString(2));
	    mb.setBill_status(rs.getString(3));
	    mb.setDealer_id(rs.getInt(4));
	   
			return mb;
		}
		
		
}

