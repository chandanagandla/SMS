package com.virtusa.dao;


	//import org.hibernate.Session;
	//import org.hibernate.SessionFactory;
	//import org.hibernate.Transaction;
	import com.virtusa.beans.*;
	import com.virtusa.dao.DealerMapper;
	//import org.hibernate.cfg.Configuration;		
		import java.util.List;
		import org.springframework.jdbc.core.JdbcTemplate;
		public class DealerDao {
			  
			JdbcTemplate template;
			public void setTemplate(JdbcTemplate template){
				this.template=template;
			}
			public int insert(Dealer dea){
				String sql="insert into Dealer(id,name,email,phonenumber,address)values(?,?,?,?,?)";
				int ans=template.update(sql,dea.getId(),dea.getName(),dea.getEmail(),dea.getphonenumber(),dea.getAddress());
				return ans;
			}

			public int update(Dealer dea){
				String sql="update Dealer set name=?, email=?, phonenumber=?, address=? where id=?";
				int ans=template.update(sql,dea.getName(),dea.getEmail(),dea.getphonenumber(),dea.getAddress(),dea.getId());
				return ans;
			}
			public int delete(int id){
				String sql="delete from Dealer where id=?";
				return template.update(sql,id);
			}
			public Dealer getDeaId(int id){
				String sql="select * from Dealer where id=?";
				Dealer dea=template.queryForObject(sql,new Object[]{id},new DealerMapper());
				
				return dea;
			}
			
			public List<Dealer> getDealerDetails(){
				String sql="select * from Dealer";
				List<Dealer>deaList=template.query(sql,new DealerMapper());
				return deaList;
			}
			
			
			
		}





