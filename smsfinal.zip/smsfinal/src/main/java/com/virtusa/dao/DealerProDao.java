package com.virtusa.dao;


	//import org.hibernate.Session;
	//import org.hibernate.SessionFactory;
	//import org.hibernate.Transaction;
	import com.virtusa.beans.*;
	import com.virtusa.dao.DealerProMapper;
	//import org.hibernate.cfg.Configuration;		
		import java.util.List;
		import org.springframework.jdbc.core.JdbcTemplate;
		public class DealerProDao{
			  
			JdbcTemplate template;
			public void setTemplate(JdbcTemplate template){
				this.template=template;
			}
			public int insert(DealerProduct dp){
				String sql="insert into DealerProducts(Product_id,Product_type,Product_name,Manufacturer_id,Manu_Date,sellingprice,Quantity)values(?,?,?,?,?,?,?)";
				int ans=template.update(sql,dp.getProduct_id(),dp.getProduct_type(),dp.getProduct_name(),dp.getManufacturer_Id(),dp.getManu_Date(),dp.getQuantity());
				return ans;
			}

			public int update(DealerProduct dp){
				String sql="update DealerProducts set Product_type=?, Product_name=?,Manufacturer_id, Manu_Date=?, sellingprice=?,Quantity=? where Product_id=?";
				int ans=template.update(sql,dp.getProduct_type(),dp.getProduct_name(),dp.getManufacturer_Id(),dp.getManu_Date(),dp.getSellingPrice(),dp.getQuantity(),dp.getProduct_id());
				return ans;
			}
			public int delete(int Product_id){
				String sql="delete from DealerProducts where Product_id=?";
				return template.update(sql,Product_id);
			}
			public DealerProduct getdpProduct_id(int Product_id){
				String sql="select * from DealerProducts where Product_id=?";
				DealerProduct dp=template.queryForObject(sql,new Object[]{Product_id},new DealerProMapper());
				
				return dp;
			}
			
			public List<DealerProduct> getDealerProductDetails(){
				String sql="select * from DealerProducts";
				List<DealerProduct>dpList=template.query(sql,new DealerProMapper());
				return dpList;
			}
			
			
			
		}





