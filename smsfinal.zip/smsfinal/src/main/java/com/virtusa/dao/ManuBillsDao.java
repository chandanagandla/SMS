package com.virtusa.dao;


	//import org.hibernate.Session;
	//import org.hibernate.SessionFactory;
	//import org.hibernate.Transaction;
	import com.virtusa.beans.*;
	import com.virtusa.dao.	ManuBillMapper;
	//import org.hibernate.cfg.Configuration;		
		import java.util.List;
		import org.springframework.jdbc.core.JdbcTemplate;
		public class ManuBillsDao {
			  
			JdbcTemplate template;
			public void setTemplate(JdbcTemplate template){
				this.template=template;
			}
			public int insert(ManufacturerBills mb){
				String sql="insert into ManufacturerBills(Bill_id,Bill_date,Bill_status,Dealer_id)values(?,?,?,?)";
				int ans=template.update(sql,mb.getBill_id(),mb.getBill_date(),mb.getBill_status(),mb.getDealer_id());
				return ans;
			}

			public int update(ManufacturerBills mb){
				String sql="update ManufacturerBills set Bill_date=?, Bill_status=?, Dealer_id=? where Bill_id=?";
				int ans=template.update(sql,mb.getBill_date(),mb.getBill_status(),mb.getDealer_id(),mb.getBill_id());
				return ans;
			}
			public int delete(int Bill_id){
				String sql="delete from ManufacturerBills where Bill_id=?";
				return template.update(sql,Bill_id);
			}
			public ManufacturerBills getmbBill_id(int Bill_id){
				String sql="select * from ManufacturerBills where Bill_id=?";
				ManufacturerBills mb=template.queryForObject(sql,new Object[]{Bill_id},new ManuBillMapper());
				
				return mb;
			}
			
			public List<ManufacturerBills> getManufacturerBillsDetails(){
				String sql="select * from ManufacturerBills";
				List<ManufacturerBills>mbList=template.query(sql,new ManuBillMapper());
				return mbList;
			}
			
			
			
		}



	
