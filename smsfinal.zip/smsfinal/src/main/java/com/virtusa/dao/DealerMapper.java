package com.virtusa.dao;


	import java.sql.ResultSet;
	import java.sql.SQLException;

	import org.springframework.jdbc.core.RowMapper;

	import com.virtusa.beans.*;

	public class DealerMapper implements RowMapper<Dealer>{

		@Override
		public Dealer mapRow(ResultSet rs, int rowNum)throws SQLException{
	  Dealer dea =new Dealer();
	    dea.setId(rs.getInt(1));
	    dea.setName(rs.getString(2));
	    dea.setEmail(rs.getString(3));
	    dea.setphonenumber(rs.getString(4));
	    dea.setAddress(rs.getString(5));
			return dea;
		}
		


}
