package com.virtusa.dao;


	//import org.hibernate.Session;
	//import org.hibernate.SessionFactory;
	//import org.hibernate.Transaction;
	import com.virtusa.beans.*;
	import com.virtusa.dao.ManuProMapper;
	//import org.hibernate.cfg.Configuration;		
		import java.util.List;
		import org.springframework.jdbc.core.JdbcTemplate;
		public class ManuProDao{
			  
			JdbcTemplate template;
			public void setTemplate(JdbcTemplate template){
				this.template=template;
			}
			public int insert(ManufacturerProduct mp){
				String sql="insert into ManufacturerProduct(Product_id,Product_type,Product_name,Manu_Date,Manu_Cp,Quantity)values(?,?,?,?,?,?)";
				int ans=template.update(sql,mp.getProduct_id(),mp.getProduct_type(),mp.getProduct_name(),mp.getManu_Date(),mp.getManu_Cp(),mp.getQuantity());
				return ans;
			}

			public int update(ManufacturerProduct mp){
				String sql="update ManufacturerProduct set Product_type=?, Product_name=?, Manu_Date=?, Manu_Cp=?,Quantity=? where Product_id=?";
				int ans=template.update(sql,mp.getProduct_type(),mp.getProduct_name(),mp.getManu_Date(),mp.getManu_Cp(),mp.getQuantity(),mp.getProduct_id());
				return ans;
			}
			public int delete(int Product_id){
				String sql="delete from ManufacturerProduct where Product_id=?";
				return template.update(sql,Product_id);
			}
			public ManufacturerProduct getmpProduct_id(int Product_id){
				String sql="select * from ManufacturerProduct where Product_id=?";
				ManufacturerProduct mp=template.queryForObject(sql,new Object[]{Product_id},new ManuProMapper());
				
				return mp;
			}
			
			public List<ManufacturerProduct> getManufacturerProductDetails(){
				String sql="select * from ManufacturerProduct";
				List<ManufacturerProduct>mpList=template.query(sql,new ManuProMapper());
				return mpList;
			}
			
			
			
		}





