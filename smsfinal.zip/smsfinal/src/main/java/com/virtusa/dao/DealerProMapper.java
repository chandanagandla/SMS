package com.virtusa.dao;


	import java.sql.ResultSet;
	import java.sql.SQLException;

	import org.springframework.jdbc.core.RowMapper;

	import com.virtusa.beans.*;

	public class DealerProMapper implements RowMapper<DealerProduct>{

		@Override
		public DealerProduct  mapRow(ResultSet rs, int rowNum)throws SQLException{
			DealerProduct dp = new DealerProduct();
	   dp.setProduct_id(rs.getInt(1));
	   dp.setProduct_type(rs.getString(2));
	    dp.setProduct_name(rs.getString(3));
	    dp.setManufacturer_Id(rs.getString(4));
	    dp.setManu_Date(rs.getString(5));
	    dp.setSellingPrice(rs.getFloat(6));
	    dp.setQuantity(rs.getInt(7));
			return dp;
		}
		
		
}
