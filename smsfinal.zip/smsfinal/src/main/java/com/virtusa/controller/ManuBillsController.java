package com.virtusa.controller;


	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Controller;
	import org.springframework.ui.Model;
	import org.springframework.web.bind.annotation.ModelAttribute;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RequestMethod;

	import com.virtusa.beans.*;
	import com.virtusa.controller.*;
	import com.virtusa.dao.ManuBillsDao;

	@Controller
	public class ManuBillsController {
		@Autowired
		ManuBillsDao dao;
		@RequestMapping("/Billsform")
		public String showForm(Model m){
			m.addAttribute("command", new ManufacturerBills());
			
			return "Billsform";
			
		}
		
		@RequestMapping(value="/saveeeee", method=RequestMethod.POST)
		public String save(@ModelAttribute("mb")ManufacturerBills mb){
			dao.insert(mb);
			return "redirect:/ViewBills";
		}
		@RequestMapping("/ViewBills")
		public String viewmb(Model m){
			List<ManufacturerBills> mbList= dao.getManufacturerBillsDetails();
			
			m.addAttribute("mbList",mbList);
			return "ViewBills";
		}
		
		@RequestMapping(value="/editmb/{Bill_id}")
		public String edit(@PathVariable int Bill_id, Model m){
			ManufacturerBills mb=dao.getmbBill_id(Bill_id);
			m.addAttribute("command",mb);
			return "BillsEditForm";
		}
		@RequestMapping(value="/editsaveeeee",method=RequestMethod.POST)
		public String editSave(@ModelAttribute("mb")ManufacturerBills mb){
			dao.update(mb);
			return "redirect:/ViewBills";
		}
		
		@RequestMapping(value="/deletemb/{Bill_id}")
		public String delete(@PathVariable int 	Bill_id){
			dao.delete(Bill_id);
			return "redirect:/ViewBills";
		}
		
	}
