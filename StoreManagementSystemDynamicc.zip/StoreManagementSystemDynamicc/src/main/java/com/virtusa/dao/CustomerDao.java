package com.virtusa.dao;
	
	import com.virtusa.beans.*;
	import com.virtusa.dao.CustomerMapper;
	

import java.sql.JDBCType;
import java.util.List;
		import org.springframework.jdbc.core.JdbcTemplate;
		public class CustomerDao {
			  
			JdbcTemplate template;
			public void setTemplate(JdbcTemplate template){
				this.template=template;
			}
			public int insert(Customer cus){
				String sql="insert into Customer(id,name,email,phonenumber,product_id,quantity,price)values(?,?,?,?,?,?,?)";
				int ans=template.update(sql,cus.getId(),cus.getName(),cus.getEmail(),cus.getPhonenumber(), cus.getProduct_id(),cus.getQuantity(),cus.getPrice());
				return ans;
			}

			public int update(Customer cus){
				String sql="update Customer set id=?,name=?,email=?,phonenumber=?,product_id=?,quantity=?,price=? where id=?";
				int ans=template.update(sql,cus.getId(),cus.getName(),cus.getEmail(),cus.getPhonenumber(), cus.getProduct_id(),cus.getQuantity(),cus.getPrice());
				return ans;
			}
			public int delete(int id){
				String sql="delete from customer where id=?";
				return template.update(sql,id);
			}
			public Customer getCusId(int id){
				String sql="select * from Customer where id=?";
				Customer cus=template.queryForObject(sql,new Object[]{id},new CustomerMapper());
				
				return cus;
			}
			
			public List<Customer> getCustomerDetails(){
				String sql="select * from Customer";
				List<Customer>cusList=template.query(sql,new CustomerMapper());
				return cusList;
			}
			
			
			
		}



