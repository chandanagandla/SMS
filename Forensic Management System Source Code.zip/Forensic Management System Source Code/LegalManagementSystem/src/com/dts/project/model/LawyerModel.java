package com.dts.project.model;

public class LawyerModel {
	private int lawyerid;
	private String lawyerfstname;
	private String lawyermidname;
	private String lawyerlstname;
	private String lawyerbarregdate;
	private String lawyerqualification;
	private String lawyerphoto;
	private String lawtypename;
	private String lawyeraddress;
	private String lawyerphno;
	private String lawyeremail;
	private int lawyertypeid;
	public int getLawyerid() {
		return lawyerid;
	}
	public void setLawyerid(int lawyerid) {
		this.lawyerid = lawyerid;
	}
	public String getLawyerfstname() {
		return lawyerfstname;
	}
	public void setLawyerfstname(String lawyerfstname) {
		this.lawyerfstname = lawyerfstname;
	}
	public String getLawyermidname() {
		return lawyermidname;
	}
	public void setLawyermidname(String lawyermidname) {
		this.lawyermidname = lawyermidname;
	}
	public String getLawyerlstname() {
		return lawyerlstname;
	}
	public void setLawyerlstname(String lawyerlstname) {
		this.lawyerlstname = lawyerlstname;
	}
	public String getLawyerbarregdate() {
		return lawyerbarregdate;
	}
	public void setLawyerbarregdate(String lawyerbarregdate) {
		this.lawyerbarregdate = lawyerbarregdate;
	}
	public String getLawyerqualification() {
		return lawyerqualification;
	}
	public void setLawyerqualification(String lawyerqualification) {
		this.lawyerqualification = lawyerqualification;
	}
	public String getLawyerphoto() {
		return lawyerphoto;
	}
	public void setLawyerphoto(String lawyerphoto) {
		this.lawyerphoto = lawyerphoto;
	}
	public String getLawyeraddress() {
		return lawyeraddress;
	}
	public void setLawyeraddress(String lawyeraddress) {
		this.lawyeraddress = lawyeraddress;
	}
	public String getLawyerphno() {
		return lawyerphno;
	}
	public void setLawyerphno(String lawyerphno) {
		this.lawyerphno = lawyerphno;
	}
	public String getLawyeremail() {
		return lawyeremail;
	}
	public void setLawyeremail(String lawyeremail) {
		this.lawyeremail = lawyeremail;
	}
	public int getLawyertypeid() {
		return lawyertypeid;
	}
	public void setLawyertypeid(int lawyertypeid) {
		this.lawyertypeid = lawyertypeid;
	}
	public String getLawtypename() {
		return lawtypename;
	}
	public void setLawtypename(String lawtypename) {
		this.lawtypename = lawtypename;
	}

}
