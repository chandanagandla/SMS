package com.dts.project.model;

public class CourtModel {
	private int courtid;
	private String courtname;
	private int courttypeid;
	private String courtaddress;
	private String courtphno;
	private String courtemail;
	private String courttypename;
	private String courtweblink;
	public int getCourtid() {
		return courtid;
	}
	public void setCourtid(int courtid) {
		this.courtid = courtid;
	}
	public String getCourtname() {
		return courtname;
	}
	public void setCourtname(String courtname) {
		this.courtname = courtname;
	}
	public int getCourttypeid() {
		return courttypeid;
	}
	public void setCourttypeid(int courttypeid) {
		this.courttypeid = courttypeid;
	}
	public String getCourtaddress() {
		return courtaddress;
	}
	public void setCourtaddress(String courtaddress) {
		this.courtaddress = courtaddress;
	}
	public String getCourtphno() {
		return courtphno;
	}
	public void setCourtphno(String courtphno) {
		this.courtphno = courtphno;
	}
	public String getCourtemail() {
		return courtemail;
	}
	public void setCourtemail(String courtemail) {
		this.courtemail = courtemail;
	}
	public String getCourtweblink() {
		return courtweblink;
	}
	public void setCourtweblink(String courtweblink) {
		this.courtweblink = courtweblink;
	}
	public String getCourttypename() {
		return courttypename;
	}
	public void setCourttypename(String courttypename) {
		this.courttypename = courttypename;
	}
}
