package com.dts.project.model;

public class CourtTypeModel {
	private int courttypeid;
	private String courttypename;
	private String courttypeabbr;
	private String courttypedesc;
	public int getCourttypeid() {
		return courttypeid;
	}
	public void setCourttypeid(int courttypeid) {
		this.courttypeid = courttypeid;
	}
	public String getCourttypename() {
		return courttypename;
	}
	public void setCourttypename(String courttypename) {
		this.courttypename = courttypename;
	}
	public String getCourttypeabbr() {
		return courttypeabbr;
	}
	public void setCourttypeabbr(String courttypeabbr) {
		this.courttypeabbr = courttypeabbr;
	}
	public String getCourttypedesc() {
		return courttypedesc;
	}
	public void setCourttypedesc(String courttypedesc) {
		this.courttypedesc = courttypedesc;
	}
}
