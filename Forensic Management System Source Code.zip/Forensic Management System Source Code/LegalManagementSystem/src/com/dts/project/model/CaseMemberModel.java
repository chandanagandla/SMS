package com.dts.project.model;

public class CaseMemberModel {
	private int casememberid;
	private int caseid;
	private String casememberfstname;
	private String casemembermidname;
	private String casememberlstname;
	private String membertype;
	private String sequenceno;
	private String casememberftherfstname;
	private String casememberfthermidname;
	private String casememberftherlstname;
	private String casememberaddress;
	private String dob;
	public int getCasememberid() {
		return casememberid;
	}
	public void setCasememberid(int casememberid) {
		this.casememberid = casememberid;
	}
	public int getCaseid() {
		return caseid;
	}
	public void setCaseid(int caseid) {
		this.caseid = caseid;
	}
	public String getCasememberfstname() {
		return casememberfstname;
	}
	public void setCasememberfstname(String casememberfstname) {
		this.casememberfstname = casememberfstname;
	}
	public String getCasemembermidname() {
		return casemembermidname;
	}
	public void setCasemembermidname(String casemembermidname) {
		this.casemembermidname = casemembermidname;
	}
	public String getCasememberlstname() {
		return casememberlstname;
	}
	public void setCasememberlstname(String casememberlstname) {
		this.casememberlstname = casememberlstname;
	}
	public String getMembertype() {
		return membertype;
	}
	public void setMembertype(String membertype) {
		this.membertype = membertype;
	}
	public String getSequenceno() {
		return sequenceno;
	}
	public void setSequenceno(String sequenceno) {
		this.sequenceno = sequenceno;
	}
	public String getCasememberftherfstname() {
		return casememberftherfstname;
	}
	public void setCasememberftherfstname(String casememberftherfstname) {
		this.casememberftherfstname = casememberftherfstname;
	}
	public String getCasememberfthermidname() {
		return casememberfthermidname;
	}
	public void setCasememberfthermidname(String casememberfthermidname) {
		this.casememberfthermidname = casememberfthermidname;
	}
	public String getCasememberftherlstname() {
		return casememberftherlstname;
	}
	public void setCasememberftherlstname(String casememberftherlstname) {
		this.casememberftherlstname = casememberftherlstname;
	}
	public String getCasememberaddress() {
		return casememberaddress;
	}
	public void setCasememberaddress(String casememberaddress) {
		this.casememberaddress = casememberaddress;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	
}
