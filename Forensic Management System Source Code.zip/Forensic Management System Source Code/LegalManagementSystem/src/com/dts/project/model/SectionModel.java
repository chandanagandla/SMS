package com.dts.project.model;

public class SectionModel {
private int sectionid;
private String actualsectionno;
private String sectiondesc;
private int typeoflawid;
private String lawtypename;
private String sectioncommendate;
private String sectionactivestate;
private String sectionandsubsecbit;


public int getSectionid() {
	return sectionid;
}
public void setSectionid(int sectionid) {
	this.sectionid = sectionid;
}
public String getActualsectionno() {
	return actualsectionno;
}
public void setActualsectionno(String actualsectionno) {
	this.actualsectionno = actualsectionno;
}
public String getSectiondesc() {
	return sectiondesc;
}
public void setSectiondesc(String sectiondesc) {
	this.sectiondesc = sectiondesc;
}
public int getTypeoflawid() {
	return typeoflawid;
}
public void setTypeoflawid(int typeoflawid) {
	this.typeoflawid = typeoflawid;
}
public String getSectioncommendate() {
	return sectioncommendate;
}
public void setSectioncommendate(String sectioncommendate) {
	this.sectioncommendate = sectioncommendate;
}
public String getSectionactivestate() {
	return sectionactivestate;
}
public void setSectionactivestate(String sectionactivestate) {
	this.sectionactivestate = sectionactivestate;
}
public String getSectionandsubsecbit() {
	return sectionandsubsecbit;
}
public void setSectionandsubsecbit(String sectionandsubsecbit) {
	this.sectionandsubsecbit = sectionandsubsecbit;
}
public String getLawtypename() {
	return lawtypename;
}
public void setLawtypename(String lawtypename) {
	this.lawtypename = lawtypename;
}

}
