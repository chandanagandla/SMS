package com.virtusa.dao;


	import java.sql.ResultSet;
	import java.sql.SQLException;

	import org.springframework.jdbc.core.RowMapper;

	import com.virtusa.beans.*;

	public class ManuProMapper implements RowMapper<ManufacturerProduct>{

		@Override
		public ManufacturerProduct  mapRow(ResultSet rs, int rowNum)throws SQLException{
			ManufacturerProduct mp =new ManufacturerProduct();
	   mp.setProduct_id(rs.getInt(1));
	   mp.setProduct_type(rs.getString(2));
	    mp.setProduct_name(rs.getString(3));
	    mp.setManu_Date(rs.getString(4));
	    mp.setManu_Cp(rs.getFloat(5));
	    mp.setQuantity(rs.getInt(6));
			return mp;
		}
		
		
}
