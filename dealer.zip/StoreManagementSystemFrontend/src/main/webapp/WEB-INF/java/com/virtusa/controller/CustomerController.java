
package com.virtusa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.virtusa.beans.*;
//import com.virtusa.controller.*;
import com.virtusa.dao.CustomerDao;

@Controller
public class CustomerController {
	@Autowired
	CustomerDao dao;
	@RequestMapping("/cusform")
	public String showForm(Model m){
		m.addAttribute("command", new Customer());
		System.out.println("show Form");
		return "cusform";
		
	}
	
	@RequestMapping(value="/saveeee", method=RequestMethod.POST)
	public String save(@ModelAttribute("cus")Customer cus){
		dao.insert(cus);
		return "redirect:/viewcus";
	}
	@RequestMapping("/viewcus")
	public String viewcus(Model m){
		List<Customer> cusList= dao.getCustomerDetails();
		
		m.addAttribute("cusList",cusList);
		return "viewcus";
	}
	
	@RequestMapping(value="/editcus/{id}")
	public String edit(@PathVariable int id, Model m){
		Customer cus=dao.getCusId(id);
		m.addAttribute("command",cus);
		return "cuseditform";
	}
	@RequestMapping(value="/editsaveeee",method=RequestMethod.POST)
	public String editSave(@ModelAttribute("cus")Customer cus){
		dao.update(cus);
		return "redirect:/viewcus";
	}
	
	@RequestMapping(value="/deletecus/{id}")
	public String delete(@PathVariable int id){
		dao.delete(id);
		return "redirect:/viewcus";
	}
	
}

