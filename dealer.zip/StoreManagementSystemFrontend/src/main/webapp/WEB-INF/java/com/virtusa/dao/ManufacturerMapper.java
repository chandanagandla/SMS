package com.virtusa.dao;



import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.virtusa.beans.*;

public class ManufacturerMapper implements RowMapper<Manufacturer>{

	@Override
	public Manufacturer mapRow(ResultSet rs, int rowNum)throws SQLException{
  Manufacturer man =new Manufacturer();
    man.setId(rs.getInt(1));
    man.setName(rs.getString(2));
    man.setEmail(rs.getString(3));
    man.setPhonenumber(rs.getString(4));
		
		return man;
	}
	

}
