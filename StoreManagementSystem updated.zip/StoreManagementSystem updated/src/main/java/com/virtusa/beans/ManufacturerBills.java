package com.virtusa.beans;

import java.sql.Date;

//import javax.persistence.Entity;
	//import javax.persistence.Id;

	//@Entity
	public class ManufacturerBills {
		//@Id
	int Bill_id;
	private String Bill_date ;
	private String Bill_status;
	private int Dealer_id;
	public int getBill_id() {
		return Bill_id;
	}
	public String getBill_date() {
		return Bill_date;
	}
	public void setBill_date(String bill_date) {
		Bill_date = bill_date;
	}
	public String getBill_status() {
		return Bill_status;
	}
	public void setBill_status(String bill_status) {
		Bill_status = bill_status;
	}
	public int getDealer_id() {
		return Dealer_id;
	}
	public void setDealer_id(int dealer_id) {
		Dealer_id = dealer_id;
	}
	public void setBill_id(int bill_id) {
		Bill_id = bill_id;
	}
	}
	