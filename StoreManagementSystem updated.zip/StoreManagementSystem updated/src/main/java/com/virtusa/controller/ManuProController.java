package com.virtusa.controller;


	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Controller;
	import org.springframework.ui.Model;
	import org.springframework.web.bind.annotation.ModelAttribute;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RequestMethod;

	import com.virtusa.beans.*;
	import com.virtusa.controller.*;
import com.virtusa.dao.ManuProDao;

	@Controller
	public class ManuProController {
		@Autowired
		ManuProDao dao;
		@RequestMapping("/ProductForm")
		public String showForm(Model m){
			m.addAttribute("command", new ManufacturerProduct());
			System.out.println("show Form");
			return "ProductForm";
			
		}
		
		@RequestMapping(value="/savee", method=RequestMethod.POST)
		public String save(@ModelAttribute("mp")ManufacturerProduct mp){
			dao.insert(mp);
			return "redirect:/ViewProduct";
		}
		@RequestMapping("/ViewProduct")
		public String viewmp(Model m){
			List<ManufacturerProduct> mpList= dao.getManufacturerProductDetails();
			
			m.addAttribute("mpList",mpList);
			return "ViewProduct";
		}
		
		@RequestMapping(value="/editmp/{Product_id}")
		public String edit(@PathVariable int Product_id, Model m){
			ManufacturerProduct mp=dao.getmpProduct_id(Product_id);
			m.addAttribute("command",mp);
			return "ProductEditForm";
		}
		@RequestMapping(value="/editsavee",method=RequestMethod.POST)
		public String editSave(@ModelAttribute("mp") ManufacturerProduct mp){
			dao.update(mp);
			return "redirect:/ViewProduct";
		}
		
		@RequestMapping(value="/deletemp/{Product_id}")
		public String delete(@PathVariable int Product_id){
			dao.delete(Product_id);
			return "redirect:/ViewProduct";
		}
		
	}



